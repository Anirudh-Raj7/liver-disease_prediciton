package com.example.diabetespredictionapp;

public class VolleyError {
}
