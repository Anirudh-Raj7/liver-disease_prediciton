package com.example.diabetespredictionapp;

public class Diabetes {

    public String Age_of_the_patient;
    public String Gender_of_the_patient;
    public String Alkphos_Alkaline_Phosphotase;
    public String Sgpt_Alamine_Aminotransferase;
    public String ALB_Albumin;
    public String A_G_Ratio_Albumin_and_Globulin_Ratio;

}
