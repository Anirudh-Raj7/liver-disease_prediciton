package com.example.diabetespredictionapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
public class Home extends Fragment implements View.OnClickListener {
    Context context;
    Diabetes diabetes;
    TextView textLiver;
    EditText textage, textgender, textalkphos,textalamine,textALB,textAlbumin;

    public Home() {
    }

    public static Home newInstance(String param1, String param2) {
        Home fragment = new Home();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getActivity().setTitle("Liver Disease");
        diabetes = new Diabetes();
    }

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
// Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        this.context = container.getContext();
        textage = view.findViewById(R.id.textage);
        textgender = view.findViewById(R.id.textgender);
        textalkphos = view.findViewById(R.id.textalkphos);
        textalamine = view.findViewById(R.id.textalamine);
        textALB = view.findViewById(R.id.textALB);
        textAlbumin = view.findViewById(R.id.textAlbumin);
        textLiver = view.findViewById(R.id.textLiver);
        Button btnPredict = view.findViewById(R.id.btnPredict);
        btnPredict.setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnPredict:
                diabetes.Age_of_the_patient = textage.getText().toString();
                diabetes.Gender_of_the_patient = textgender.getText().toString();
                diabetes.Alkphos_Alkaline_Phosphotase = textalkphos.getText().toString();
                diabetes.Sgpt_Alamine_Aminotransferase = textalamine.getText().toString();
                diabetes.ALB_Albumin = textALB.getText().toString();
                diabetes.A_G_Ratio_Albumin_and_Globulin_Ratio = textAlbumin.getText().toString();
                GetpredictOutcome();
                break;
        }
    }

    private void GetpredictOutcome() {
        String url = "http://3.208.241.10/predictDisease?";
        url += "Age_of_the_patient=" + diabetes.Age_of_the_patient + "&";
        url += "Gender_of_the_patient=" + diabetes.Gender_of_the_patient + "&";
        url += "Alkphos_Alkaline_Phosphotase=" + diabetes.Alkphos_Alkaline_Phosphotase + "&";
        url += "Sgpt_Alamine_Aminotransferase=" + diabetes.Sgpt_Alamine_Aminotransferase + "&";
        url += "ALB_Albumin=" + diabetes.ALB_Albumin + "&";
        url += "A_G_Ratio_Albumin_and_Globulin_Ratio=" + diabetes.A_G_Ratio_Albumin_and_Globulin_Ratio;
// creating a new variable for our request queue
        RequestQueue queue = Volley.newRequestQueue(context);
// make json array request and then extracting data from each json object.
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new
                Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            JSONObject responseObj = response.getJSONObject(0);
                            String returnValue = responseObj.getString("Result");
                            if (returnValue.equals("2")) {
                                textLiver.setText("You have Liver Disease.Please visit the Doctor");
                            } else {
                                textLiver.setText("You Dont have Liver Disease");
                            }
                        } catch (JSONException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, "Fail to get the data..", Toast.LENGTH_SHORT).show();
            }
        });
        queue.add(jsonArrayRequest);
    }
}